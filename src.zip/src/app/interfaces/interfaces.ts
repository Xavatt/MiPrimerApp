// Se agregan las interfaces para que puedan ser de manera más global y tener todas en un solo archivo

export interface ListaComponentes{
    name: string;
    icon: string;
    redirectTo: string;
  }
  